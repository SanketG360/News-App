package com.example.newsapp;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.IntentFilter;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.material.snackbar.Snackbar;
import com.jacksonandroidnetworking.JacksonParserFactory;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private static  String API_KEY="d030a56b213c4bd08184b59ace39e430";
    private  static  String  Tag = "MainActivity";
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private ArrayList<NewsModel> mArticlelist;
    private  NewsAdapter  mArticeadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AndroidNetworking.initialize(getApplicationContext());
        AndroidNetworking.setParserFactory(new JacksonParserFactory());

        progressBar = findViewById(R.id.progressbar);
        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        mArticlelist = new ArrayList<>();
        
        get_news_from_api();


    }





    public void get_news_from_api() {
        mArticlelist.clear();
        AndroidNetworking.get("https://newsapi.org/v2/top-headlines")
                .addQueryParameter("country", "in")
                .addQueryParameter("apiKey",API_KEY)
                .addHeaders("token", "1234")
                .setTag("test")
                .setPriority(Priority.LOW)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONArray articles = response.getJSONArray("articles");
                            for(int  j = 0 ; j<articles.length();j++)
                            {
                                JSONObject article=articles.getJSONObject(j);
                                NewsModel  curretArticle  = new NewsModel();
                                String title=article.getString("title");
                                String description=article.getString("description");
                                String url=article.getString("url");
                                String urlToImage=article.getString("urlToImage");

                                curretArticle.setTitle(title);
                                curretArticle.setDescription(description);
                                curretArticle.setImageid(urlToImage);
                                curretArticle.setUrl(url);

                                mArticlelist.add(curretArticle);
                            }
                            mArticeadapter = new NewsAdapter(MainActivity.this,mArticlelist);
                            recyclerView.setAdapter(mArticeadapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d(TAG,"Error : "+e.getMessage());
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.d(TAG,"Error detail : "+anError.getErrorDetail());
                        Log.d(TAG,"Error response : "+anError.getResponse());
                    }
                });
    }

}