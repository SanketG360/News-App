package com.example.newsapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.widget.ANImageView;

import java.util.ArrayList;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {
    ArrayList<NewsModel> addNews;
    Context context;

    public NewsAdapter(Context context, ArrayList<NewsModel> addNews) {
        this.addNews = addNews;
        this.context = (Context) context;
    }

    @NonNull
    @Override
    public NewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.card_layout,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsAdapter.ViewHolder holder, int position) {
        NewsModel newmodel  = (NewsModel) addNews.get(position);
        holder.title.setText(newmodel.getTitle());
        holder.desc.setText(newmodel.getDescription());
        holder.imageView.setDefaultImageResId(R.drawable.ic_launcher_foreground);
        holder.imageView.setErrorImageResId(R.drawable.ic_launcher_foreground);
        holder.imageView.setImageUrl(newmodel.getImageid());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =   new Intent(context,WebActivity.class);
                intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("url_key",newmodel.getUrl());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {

        return addNews.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title,desc;
        ANImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.texttitle);
            desc = itemView.findViewById(R.id.textdesc);
            imageView = itemView.findViewById(R.id.image);
        }
    }
}
