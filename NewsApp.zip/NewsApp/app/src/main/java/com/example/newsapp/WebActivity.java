package com.example.newsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

public class WebActivity extends AppCompatActivity {

    private static  String Tag = "WebActivity";
    private WebView webView;
    private String url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        webView = findViewById(R.id.web);
        Intent intent =  getIntent();
        if(intent!=null)
        {
            url = intent.getStringExtra("url_key");
            webView.loadUrl(url);
        }
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        finish();
    }
}